class Consts {
  Consts._();

  static const double padding = 16.0;
  static const double avatarRadius = 33.0;
  static const double height = 300.0;
}